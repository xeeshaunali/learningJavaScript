<footer>
        <div class="footer-area">
                <p>© <?php echo date("Y");?> | Employee Leave Management System<a href="https://codeastro.com"></a></p>
                <p>© <?php echo date("Y");?> | DISTRICT & SESSIONS COURT JAMSHORO<a href="https://codeastro.com"></a></p>
                <P>Implemented By <stron>Xeeshaun Ali</stron> </P>
        </div>
</footer>