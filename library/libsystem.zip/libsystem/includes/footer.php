<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Open Admin Panel and Add/View user to know Login ID</b>
      </div>
      <strong>&copy; 2022 - District & Sessions Court Jamshoro | Library Management System | Brought To You By <a href="http://xeedesigns.com/">Xeeshaun</a></strong>
      </div>
    <!-- /.container -->
</footer>