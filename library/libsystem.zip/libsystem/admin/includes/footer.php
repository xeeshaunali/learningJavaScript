<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; 2022 - District & Sessions Court Jamshoro | Library Management System | Brought To You By <a href="http://xeedesigns.com/">Xeeshaun</a></strong>
</footer>